# Mega TNT Pack (Minecraft 1.7.10, Forge 10.13.4.1614)

13 new TNT blocks in one creative tab ("Mega TNT Pack"). Light them with flint & steel,
a fire charge, redstone, or let another explosion set them off (chain reactions work).

| TNT | What it does | Recipe (shapeless unless noted) |
|---|---|---|
| **Nuke** | Huge crater, then lingering **radioactive fallout** for ~20 s. Players nearby get **radiation sickness** (see below). | 8 TNT around a diamond block (shaped) |
| **Black Hole** | Invisible hole grows for 15 s, pulls in every entity within 40 blocks, deletes blocks, hurts what reaches the core, then collapses in a big blast. | TNT, 2 obsidian, ender pearl |
| **Village** | Builds a furnished house (door, windows, torch, crafting table, loot chest) and spawns a villager. | TNT, planks, cobblestone, wooden door |
| **Lightning** | 25 lightning strikes across a 40x40 area. | TNT, gold ingot, 2 redstone |
| **Ice Age** | Freezes water, cools lava to obsidian/cobble, covers the ground in snow, slows creatures. | TNT, ice, snowball |
| **Lava** | Digs a pit full of lava and splashes lava around. | TNT, lava bucket |
| **Inferno** | Sets the whole area and everything in it on fire. | TNT, blaze powder, flint |
| **Forest** | Grows oak/birch/big trees and flowers around. | TNT, sapling, bone meal |
| **Ore** | Turns surrounding stone into coal, iron, gold, redstone, lapis, diamond, emerald. | TNT, iron ore, gold ore |
| **Zombie Horde** | Spawns 15 zombies (some babies). | TNT, 2 rotten flesh, bone |
| **Party** | Spawns 20 colorful sheep, some rainbow ("jeb_"), with fireworks sounds. | TNT, wool, sugar |
| **Launch** | Blasts everything nearby sky-high (you get Resistance so the landing doesn't kill you). | TNT, piston, feather |
| **Flood** | Fills the area with water. | TNT, water bucket |

All of them are also in the creative tab.

## Radiation sickness (Nuke)
* Exposure is higher the closer you are; fallout keeps adding more while you stay near ground zero.
* While sick you slowly take damage (armor doesn't help), and get nausea, weakness and hunger.
* Every minute of sickness permanently removes **1 heart of max health** (down to a minimum of 1 heart).
* **Drinking milk** cures the sickness itself. Lost hearts come back only when you die/respawn.
* Creative-mode players are immune.

## Building the mod
1. Download the Forge 1.7.10 MDK (build 10.13.4.1614) and set it up as usual
   (`gradlew setupDecompWorkspace`, then `gradlew eclipse` or `gradlew idea`).
2. Copy this project's `src/` folder over the MDK's `src/` (and use this `build.gradle`).
3. `gradlew build` produces the mod jar in `build/libs/`.

## Adding your own TNT
1. Add an entry to `TntType.java` (append at the end; the order is the block metadata).
2. Add its effect to the `switch` in `TntEffects.detonate(...)`.
3. Add `tnt_<id>.png` (16x16) to `assets/megatnt/textures/blocks/`.
4. Add `tile.megatnt.<id>.name=...` to `en_US.lang`.
5. Add a recipe in `Recipes.java`.

(There is room for 16 variants total, since the variant is stored in the block metadata.)

## Notes
* Textures were generated programmatically as simple 16x16 pixel art, one icon per TNT
  (radiation symbol, black hole, house, lightning bolt, snowflake, lava, flame, tree, ore, zombie face, sheep, arrow, waves).
  Replace the PNGs with anything you like; just keep the file names.
* The Nuke and Black Hole are heavy. Expect lag, especially on weak PCs or big servers.
