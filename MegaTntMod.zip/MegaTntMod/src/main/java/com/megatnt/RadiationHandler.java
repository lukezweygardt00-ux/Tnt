package com.megatnt;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.Side;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.event.entity.player.PlayerUseItemEvent;

import java.util.UUID;

/**
 * Radiation sickness from the Nuke TNT.
 *
 *  - While sick: slow damage, nausea, weakness, hunger.
 *  - Every minute of sickness permanently (until death) removes 1 heart of max health,
 *    down to a minimum of 2 hearts.
 *  - Drinking milk cures the sickness, but lost hearts stay lost until you die.
 *  - Creative-mode players are immune.
 */
public class RadiationHandler {

    public static final String TAG_TICKS = "megatnt_rad_ticks";
    public static final String TAG_ACCUM = "megatnt_rad_accum";
    public static final String TAG_LOST = "megatnt_lost_hp";

    private static final int MAX_SICK_TICKS = 24000;   // 20 minutes
    private static final int TICKS_PER_HEART = 1200;   // 1 minute of sickness = 1 heart
    private static final int MAX_LOST_HP = 18;          // always keep 1 heart

    private static final UUID MODIFIER_ID = UUID.fromString("c0ffee00-1d1e-4b0b-9a1a-7e57ab1e0001");

    public static final DamageSource RADIATION = new DamageSource("megatnt.radiation") {
        { setDamageBypassesArmor(); }
    };

    /** Add radiation exposure (in ticks of sickness) to a player. */
    public static void irradiate(EntityPlayer player, int ticks) {
        if (player.capabilities.isCreativeMode || ticks <= 0) {
            return;
        }
        NBTTagCompound data = player.getEntityData();
        int current = data.getInteger(TAG_TICKS);
        if (current <= 0 && !player.worldObj.isRemote) {
            player.addChatMessage(new ChatComponentText(
                    EnumChatFormatting.GREEN + "You feel sick... you have been exposed to radiation! "
                            + "Drink milk to cure it."));
        }
        data.setInteger(TAG_TICKS, Math.min(current + ticks, MAX_SICK_TICKS));
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != Side.SERVER) {
            return;
        }
        EntityPlayer player = event.player;
        NBTTagCompound data = player.getEntityData();

        if (player.capabilities.isCreativeMode) {
            data.setInteger(TAG_TICKS, 0);
            data.setInteger(TAG_LOST, 0);
        }

        int ticks = data.getInteger(TAG_TICKS);
        if (ticks > 0 && !player.isDead) {
            data.setInteger(TAG_TICKS, ticks - 1);

            if (ticks % 80 == 0) {
                player.attackEntityFrom(RADIATION, 1.0F);
            }
            if (ticks % 200 == 0) {
                player.addPotionEffect(new PotionEffect(Potion.confusion.id, 160, 0));
            }
            if (ticks % 100 == 0) {
                player.addPotionEffect(new PotionEffect(Potion.weakness.id, 200, 0));
                player.addPotionEffect(new PotionEffect(Potion.hunger.id, 200, 0));
            }

            int accum = data.getInteger(TAG_ACCUM) + 1;
            if (accum >= TICKS_PER_HEART) {
                accum = 0;
                int lost = Math.min(data.getInteger(TAG_LOST) + 2, MAX_LOST_HP);
                data.setInteger(TAG_LOST, lost);
                player.addChatMessage(new ChatComponentText(
                        EnumChatFormatting.DARK_GREEN + "The radiation is eating away at your health..."));
            }
            data.setInteger(TAG_ACCUM, accum);
        }

        applyMaxHealth(player, data.getInteger(TAG_LOST));
    }

    private void applyMaxHealth(EntityPlayer player, int lost) {
        IAttributeInstance attr = player.getEntityAttribute(SharedMonsterAttributes.maxHealth);
        AttributeModifier existing = attr.getModifier(MODIFIER_ID);

        if (lost <= 0) {
            if (existing != null) {
                attr.removeModifier(existing);
            }
            return;
        }

        double wanted = -lost;
        if (existing == null || existing.getAmount() != wanted) {
            if (existing != null) {
                attr.removeModifier(existing);
            }
            attr.applyModifier(new AttributeModifier(MODIFIER_ID, "Radiation sickness", wanted, 0)
                    .setSaved(false));
        }
        if (player.getHealth() > player.getMaxHealth()) {
            player.setHealth(player.getMaxHealth());
        }
    }

    /** Milk cures the sickness (but not hearts that were already lost). */
    @SubscribeEvent
    public void onUseItemFinish(PlayerUseItemEvent.Finish event) {
        if (event.item != null && event.item.getItem() == Items.milk_bucket
                && !event.entityPlayer.worldObj.isRemote) {
            NBTTagCompound data = event.entityPlayer.getEntityData();
            if (data.getInteger(TAG_TICKS) > 0) {
                data.setInteger(TAG_TICKS, 0);
                data.setInteger(TAG_ACCUM, 0);
                event.entityPlayer.addChatMessage(new ChatComponentText(
                        EnumChatFormatting.AQUA + "The milk soothes the radiation sickness."));
            }
        }
    }
}
