package com.megatnt;

import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemDoor;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.world.World;

/** Builds the small furnished house (plus a villager) for the Village TNT. */
public final class HouseBuilder {

    private HouseBuilder() {}

    /**
     * @param cx,cy,cz centre of the house; cy is the level the player would stand on
     */
    public static void build(World w, int cx, int cy, int cz) {
        // 1. clear the space and lay the floor
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                w.setBlock(cx + dx, cy - 1, cz + dz, Blocks.cobblestone, 0, 2);
                for (int dy = 0; dy <= 5; dy++) {
                    w.setBlockToAir(cx + dx, cy + dy, cz + dz);
                }
            }
        }

        // 2. walls, corner logs, windows, roof
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                boolean edgeX = Math.abs(dx) == 3;
                boolean edgeZ = Math.abs(dz) == 3;
                boolean corner = edgeX && edgeZ;
                boolean wall = edgeX || edgeZ;

                for (int dy = 0; dy <= 3; dy++) {
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    if (corner) {
                        w.setBlock(x, y, z, Blocks.log, 0, 2);
                    } else if (wall) {
                        boolean middle = (dx == 0 || dz == 0);
                        boolean doorSpot = (dx == 0 && dz == 3);
                        if (doorSpot && dy <= 1) {
                            continue; // door goes here
                        }
                        if (middle && (dy == 1 || dy == 2)) {
                            w.setBlock(x, y, z, Blocks.glass_pane, 0, 2);
                        } else {
                            w.setBlock(x, y, z, Blocks.planks, 0, 2);
                        }
                    }
                }

                // roof (slightly sloped look: planks plus a slab ridge)
                w.setBlock(cx + dx, cy + 4, cz + dz, Blocks.planks, 0, 2);
                if (Math.abs(dx) <= 1 && Math.abs(dz) <= 2) {
                    w.setBlock(cx + dx, cy + 5, cz + dz, Blocks.wooden_slab, 0, 2);
                }
            }
        }

        // 3. door
        ItemDoor.placeDoorBlock(w, cx, cy, cz + 3, 1, Blocks.wooden_door);

        // 4. furniture
        w.setBlock(cx - 2, cy, cz - 2, Blocks.torch, 5, 2);
        w.setBlock(cx + 2, cy, cz - 2, Blocks.crafting_table, 0, 2);
        w.setBlock(cx - 2, cy, cz + 2, Blocks.chest, 2, 2);

        TileEntity te = w.getTileEntity(cx - 2, cy, cz + 2);
        if (te instanceof TileEntityChest) {
            TileEntityChest chest = (TileEntityChest) te;
            chest.setInventorySlotContents(0, new ItemStack(Items.bread, 6));
            chest.setInventorySlotContents(1, new ItemStack(Items.emerald, 3));
            chest.setInventorySlotContents(2, new ItemStack(Items.iron_ingot, 4));
            chest.setInventorySlotContents(4, new ItemStack(Items.apple, 5));
        }

        // 5. the resident
        if (!w.isRemote) {
            EntityVillager villager = new EntityVillager(w, w.rand.nextInt(5));
            villager.setLocationAndAngles(cx + 0.5, cy, cz + 0.5, w.rand.nextFloat() * 360.0F, 0.0F);
            w.spawnEntityInWorld(villager);
        }
    }
}
