package com.megatnt;

import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

/** Every variant is made from a vanilla TNT plus a thematic ingredient. */
public final class Recipes {

    private Recipes() {}

    private static ItemStack out(TntType type) {
        return new ItemStack(MegaTntMod.megaTnt, 1, type.ordinal());
    }

    public static void register() {
        Object tnt = Blocks.tnt;
        ItemStack anyPlanks = new ItemStack(Blocks.planks, 1, OreDictionary.WILDCARD_VALUE);
        ItemStack anySapling = new ItemStack(Blocks.sapling, 1, OreDictionary.WILDCARD_VALUE);
        ItemStack anyWool = new ItemStack(Blocks.wool, 1, OreDictionary.WILDCARD_VALUE);
        ItemStack boneMeal = new ItemStack(Items.dye, 1, 15);

        // Nuke: ring of 8 TNT around a diamond block
        GameRegistry.addShapedRecipe(out(TntType.NUKE),
                "TTT", "TDT", "TTT",
                'T', Blocks.tnt, 'D', Blocks.diamond_block);

        GameRegistry.addShapelessRecipe(out(TntType.BLACK_HOLE),
                tnt, Blocks.obsidian, Blocks.obsidian, Items.ender_pearl);
        GameRegistry.addShapelessRecipe(out(TntType.VILLAGE),
                tnt, anyPlanks, Blocks.cobblestone, Items.wooden_door);
        GameRegistry.addShapelessRecipe(out(TntType.LIGHTNING),
                tnt, Items.gold_ingot, Items.redstone, Items.redstone);
        GameRegistry.addShapelessRecipe(out(TntType.ICE),
                tnt, Blocks.ice, Items.snowball);
        GameRegistry.addShapelessRecipe(out(TntType.LAVA),
                tnt, Items.lava_bucket);
        GameRegistry.addShapelessRecipe(out(TntType.FIRE),
                tnt, Items.blaze_powder, Items.flint);
        GameRegistry.addShapelessRecipe(out(TntType.FOREST),
                tnt, anySapling, boneMeal);
        GameRegistry.addShapelessRecipe(out(TntType.ORE),
                tnt, Blocks.iron_ore, Blocks.gold_ore);
        GameRegistry.addShapelessRecipe(out(TntType.ZOMBIE),
                tnt, Items.rotten_flesh, Items.rotten_flesh, Items.bone);
        GameRegistry.addShapelessRecipe(out(TntType.PARTY),
                tnt, anyWool, Items.sugar);
        GameRegistry.addShapelessRecipe(out(TntType.LAUNCH),
                tnt, Blocks.piston, Items.feather);
        GameRegistry.addShapelessRecipe(out(TntType.FLOOD),
                tnt, Items.water_bucket);
    }
}
