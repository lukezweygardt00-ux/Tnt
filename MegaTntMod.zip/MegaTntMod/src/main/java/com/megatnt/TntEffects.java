package com.megatnt;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenForest;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.util.ForgeDirection;

import java.util.List;
import java.util.Random;

/** All server-side behaviour of the TNT variants. */
public final class TntEffects {

    private TntEffects() {}

    // ---- dispatch ---------------------------------------------------------

    public static void detonate(World w, Entity e, TntType type, EntityLivingBase igniter) {
        int x = MathHelper.floor_double(e.posX);
        int y = MathHelper.floor_double(e.posY);
        int z = MathHelper.floor_double(e.posZ);

        switch (type) {
            case NUKE:       nuke(w, e, x, y, z);   break;
            case BLACK_HOLE: w.playSoundEffect(e.posX, e.posY, e.posZ, "random.explode", 4.0F, 0.5F); break;
            case VILLAGE:    HouseBuilder.build(w, x, y, z); boom(w, e, 1.0F); break;
            case LIGHTNING:  lightning(w, x, z);    break;
            case ICE:        ice(w, x, y, z);       break;
            case LAVA:       lava(w, x, y, z);      break;
            case FIRE:       fire(w, x, y, z);      break;
            case FOREST:     forest(w, x, y, z);    break;
            case ORE:        ore(w, x, y, z);       break;
            case ZOMBIE:     zombies(w, e);         break;
            case PARTY:      party(w, e);           break;
            case LAUNCH:     launch(w, e);          break;
            case FLOOD:      flood(w, x, y, z);     break;
            default: break;
        }
    }

    /** Called every tick while a lingering TNT (nuke fallout / black hole) is active. */
    public static void lingerTick(World w, Entity e, TntType type, int elapsed, int total) {
        if (type == TntType.NUKE) {
            fallout(w, e, elapsed);
        } else if (type == TntType.BLACK_HOLE) {
            blackHole(w, e, elapsed, total);
        }
    }

    public static void lingerEnd(World w, Entity e, TntType type) {
        if (type == TntType.BLACK_HOLE) {
            // the hole collapses with a bang
            w.createExplosion(e, e.posX, e.posY, e.posZ, 10.0F, true);
        }
    }

    // ---- helpers ----------------------------------------------------------

    private static void boom(World w, Entity e, float power) {
        w.createExplosion(e, e.posX, e.posY, e.posZ, power, false);
    }

    private static boolean inSphere(int dx, int dy, int dz, int r) {
        return dx * dx + dy * dy + dz * dz <= r * r;
    }

    @SuppressWarnings("unchecked")
    private static List<Entity> entitiesAround(World w, Entity e, double r) {
        AxisAlignedBB box = AxisAlignedBB.getBoundingBox(
                e.posX - r, e.posY - r, e.posZ - r, e.posX + r, e.posY + r, e.posZ + r);
        return (List<Entity>) w.getEntitiesWithinAABBExcludingEntity(e, box);
    }

    // ---- NUKE -------------------------------------------------------------

    private static void nuke(World w, Entity e, int x, int y, int z) {
        // main blast plus a few offset blasts for a rough crater
        w.createExplosion(e, e.posX, e.posY, e.posZ, 24.0F, true);
        Random r = w.rand;
        for (int i = 0; i < 6; i++) {
            double ox = (r.nextDouble() - 0.5) * 24.0;
            double oz = (r.nextDouble() - 0.5) * 24.0;
            double oy = (r.nextDouble() - 0.3) * 8.0;
            w.createExplosion(e, e.posX + ox, e.posY + oy, e.posZ + oz, 8.0F, true);
        }
        // everyone nearby gets a big radiation dose
        irradiateAround(w, e, 96.0, 6000);
    }

    /** Radioactive fallout: keeps irradiating players near the blast site. */
    private static void fallout(World w, Entity e, int elapsed) {
        if (elapsed % 20 == 0) {
            irradiateAround(w, e, 48.0, 1200);
        }
    }

    private static void irradiateAround(World w, Entity e, double radius, int baseTicks) {
        AxisAlignedBB box = AxisAlignedBB.getBoundingBox(
                e.posX - radius, e.posY - radius, e.posZ - radius,
                e.posX + radius, e.posY + radius, e.posZ + radius);
        for (Object o : w.getEntitiesWithinAABB(EntityPlayer.class, box)) {
            EntityPlayer p = (EntityPlayer) o;
            double d = p.getDistanceToEntity(e);
            if (d > radius) {
                continue;
            }
            double scale = 1.0 - (d / radius) * 0.5; // closer = more dose
            RadiationHandler.irradiate(p, (int) (baseTicks * scale));
        }
    }

    // ---- BLACK HOLE -------------------------------------------------------

    private static void blackHole(World w, Entity e, int elapsed, int total) {
        double progress = (double) elapsed / (double) total;
        double radius = 2.0 + 11.0 * progress;   // eats a sphere that grows from r=2 to r=13
        double pullRange = 40.0;

        // pull everything toward the centre
        for (Entity t : entitiesAround(w, e, pullRange)) {
            if (t instanceof EntityPlayer && ((EntityPlayer) t).capabilities.isCreativeMode) {
                continue;
            }
            double dx = e.posX - t.posX;
            double dy = (e.posY + 0.5) - t.posY;
            double dz = e.posZ - t.posZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist < 0.5) {
                dist = 0.5;
            }
            double pull = Math.min(0.12 + 2.0 / dist, 1.2);
            t.motionX += dx / dist * pull * 0.35;
            t.motionY += dy / dist * pull * 0.35;
            t.motionZ += dz / dist * pull * 0.35;
            t.velocityChanged = true;
            t.fallDistance = 0.0F;

            // crushed at the core
            if (dist < radius * 0.6 && elapsed % 5 == 0 && t instanceof EntityLivingBase) {
                t.attackEntityFrom(DamageSource.outOfWorld, 4.0F);
            }
        }

        // devour blocks inside the sphere
        int cx = MathHelper.floor_double(e.posX);
        int cy = MathHelper.floor_double(e.posY);
        int cz = MathHelper.floor_double(e.posZ);
        int r = (int) Math.ceil(radius);
        Random rnd = w.rand;
        for (int i = 0; i < 250; i++) {
            int dx = rnd.nextInt(2 * r + 1) - r;
            int dy = rnd.nextInt(2 * r + 1) - r;
            int dz = rnd.nextInt(2 * r + 1) - r;
            if (dx * dx + dy * dy + dz * dz > radius * radius) {
                continue;
            }
            int bx = cx + dx, by = cy + dy, bz = cz + dz;
            if (by < 1) {
                continue;
            }
            Block b = w.getBlock(bx, by, bz);
            if (b != Blocks.air && b != Blocks.bedrock) {
                w.setBlock(bx, by, bz, Blocks.air, 0, 2);
            }
        }

        if (elapsed % 20 == 0) {
            w.playSoundEffect(e.posX, e.posY, e.posZ, "portal.travel", 1.0F, 0.5F);
        }
    }

    // ---- LIGHTNING --------------------------------------------------------

    private static void lightning(World w, int x, int z) {
        Random r = w.rand;
        for (int i = 0; i < 25; i++) {
            int bx = x + r.nextInt(41) - 20;
            int bz = z + r.nextInt(41) - 20;
            int by = w.getTopSolidOrLiquidBlock(bx, bz);
            w.addWeatherEffect(new EntityLightningBolt(w, bx, by, bz));
        }
    }

    // ---- ICE --------------------------------------------------------------

    private static void ice(World w, int cx, int cy, int cz) {
        int r = 12;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (!inSphere(dx, dy, dz, r)) continue;
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    Block b = w.getBlock(x, y, z);
                    if (b == Blocks.water || b == Blocks.flowing_water) {
                        w.setBlock(x, y, z, Blocks.ice, 0, 2);
                    } else if (b == Blocks.lava) {
                        w.setBlock(x, y, z, Blocks.obsidian, 0, 2);
                    } else if (b == Blocks.flowing_lava) {
                        w.setBlock(x, y, z, Blocks.cobblestone, 0, 2);
                    } else if (b == Blocks.air && y > 0
                            && w.isSideSolid(x, y - 1, z, ForgeDirection.UP)) {
                        w.setBlock(x, y, z, Blocks.snow_layer, 0, 2);
                    }
                }
            }
        }
        // freeze creatures in place
        AxisAlignedBB box = AxisAlignedBB.getBoundingBox(cx - r, cy - r, cz - r, cx + r, cy + r, cz + r);
        for (Object o : w.getEntitiesWithinAABB(EntityLivingBase.class, box)) {
            ((EntityLivingBase) o).addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 200, 3));
        }
        w.playSoundEffect(cx, cy, cz, "random.glass", 2.0F, 0.6F);
    }

    // ---- LAVA -------------------------------------------------------------

    private static void lava(World w, int cx, int cy, int cz) {
        int r = 4;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;
                for (int dy = -2; dy <= 0; dy++) {
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    Block b = w.getBlock(x, y, z);
                    if (b != Blocks.bedrock) {
                        w.setBlock(x, y, z, Blocks.flowing_lava, 0, 3);
                    }
                }
            }
        }
        // splash lava droplets nearby
        Random rnd = w.rand;
        for (int i = 0; i < 20; i++) {
            int x = cx + rnd.nextInt(15) - 7;
            int z = cz + rnd.nextInt(15) - 7;
            int y = w.getTopSolidOrLiquidBlock(x, z);
            if (w.isAirBlock(x, y, z)) {
                w.setBlock(x, y, z, Blocks.flowing_lava, 0, 3);
            }
        }
        w.playSoundEffect(cx, cy, cz, "liquid.lavapop", 2.0F, 0.5F);
    }

    // ---- FIRE -------------------------------------------------------------

    private static void fire(World w, int cx, int cy, int cz) {
        int r = 10;
        Random rnd = w.rand;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (!inSphere(dx, dy, dz, r)) continue;
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    if (w.isAirBlock(x, y, z) && y > 0
                            && !w.isAirBlock(x, y - 1, z) && rnd.nextInt(3) == 0) {
                        w.setBlock(x, y, z, Blocks.fire, 0, 2);
                    }
                }
            }
        }
        AxisAlignedBB box = AxisAlignedBB.getBoundingBox(cx - r, cy - r, cz - r, cx + r, cy + r, cz + r);
        for (Object o : w.getEntitiesWithinAABB(EntityLivingBase.class, box)) {
            ((EntityLivingBase) o).setFire(10);
        }
        w.playSoundEffect(cx, cy, cz, "mob.ghast.fireball", 2.0F, 0.8F);
    }

    // ---- FOREST -----------------------------------------------------------

    private static void forest(World w, int cx, int cy, int cz) {
        Random rnd = w.rand;
        for (int i = 0; i < 18; i++) {
            int x = cx + rnd.nextInt(33) - 16;
            int z = cz + rnd.nextInt(33) - 16;
            int y = w.getTopSolidOrLiquidBlock(x, z);
            Block below = w.getBlock(x, y - 1, z);
            if (below != Blocks.grass && below != Blocks.dirt) {
                continue;
            }
            WorldGenerator gen;
            switch (rnd.nextInt(3)) {
                case 0:  gen = new WorldGenTrees(true);       break;
                case 1:  gen = new WorldGenForest(true, false); break;
                default: gen = new WorldGenBigTree(true);     break;
            }
            gen.generate(w, rnd, x, y, z);
        }
        // flowers and grass on the ground
        for (int i = 0; i < 60; i++) {
            int x = cx + rnd.nextInt(25) - 12;
            int z = cz + rnd.nextInt(25) - 12;
            int y = w.getTopSolidOrLiquidBlock(x, z);
            if (w.isAirBlock(x, y, z) && w.getBlock(x, y - 1, z) == Blocks.grass) {
                Block plant = rnd.nextBoolean() ? Blocks.yellow_flower : Blocks.red_flower;
                w.setBlock(x, y, z, plant, 0, 2);
            }
        }
        w.playSoundEffect(cx, cy, cz, "random.levelup", 1.5F, 0.8F);
    }

    // ---- ORE --------------------------------------------------------------

    private static void ore(World w, int cx, int cy, int cz) {
        int r = 10;
        Random rnd = w.rand;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (!inSphere(dx, dy, dz, r)) continue;
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    if (w.getBlock(x, y, z) != Blocks.stone) continue;
                    float roll = rnd.nextFloat();
                    Block ore = null;
                    if (roll < 0.005F)      ore = Blocks.emerald_ore;
                    else if (roll < 0.015F) ore = Blocks.diamond_ore;
                    else if (roll < 0.030F) ore = Blocks.lapis_ore;
                    else if (roll < 0.050F) ore = Blocks.gold_ore;
                    else if (roll < 0.075F) ore = Blocks.redstone_ore;
                    else if (roll < 0.110F) ore = Blocks.iron_ore;
                    else if (roll < 0.160F) ore = Blocks.coal_ore;
                    if (ore != null) {
                        w.setBlock(x, y, z, ore, 0, 2);
                    }
                }
            }
        }
        // small pop so you know it worked, without destroying the ore
        w.playSoundEffect(cx, cy, cz, "random.orb", 2.0F, 0.5F);
    }

    // ---- ZOMBIE -----------------------------------------------------------

    private static void zombies(World w, Entity e) {
        Random rnd = w.rand;
        for (int i = 0; i < 15; i++) {
            EntityZombie z = new EntityZombie(w);
            z.setLocationAndAngles(e.posX + rnd.nextDouble() * 8 - 4, e.posY + 0.5,
                    e.posZ + rnd.nextDouble() * 8 - 4, rnd.nextFloat() * 360.0F, 0.0F);
            if (rnd.nextInt(4) == 0) {
                z.setChild(true);
            }
            w.spawnEntityInWorld(z);
        }
        boom(w, e, 1.5F);
    }

    // ---- PARTY ------------------------------------------------------------

    private static void party(World w, Entity e) {
        Random rnd = w.rand;
        for (int i = 0; i < 20; i++) {
            EntitySheep s = new EntitySheep(w);
            s.setLocationAndAngles(e.posX + rnd.nextDouble() * 8 - 4, e.posY + 0.5,
                    e.posZ + rnd.nextDouble() * 8 - 4, rnd.nextFloat() * 360.0F, 0.0F);
            s.setFleeceColor(rnd.nextInt(16));
            if (i % 5 == 0) {
                s.setCustomNameTag("jeb_"); // rainbow sheep
            }
            w.spawnEntityInWorld(s);
        }
        w.playSoundEffect(e.posX, e.posY, e.posZ, "fireworks.blast", 3.0F, 1.0F);
        w.playSoundEffect(e.posX, e.posY, e.posZ, "fireworks.twinkle", 3.0F, 1.0F);
    }

    // ---- LAUNCH -----------------------------------------------------------

    private static void launch(World w, Entity e) {
        for (Entity t : entitiesAround(w, e, 14.0)) {
            t.motionY = 3.0;
            t.velocityChanged = true;
            if (t instanceof EntityLivingBase) {
                // soft landing so it stays fun
                ((EntityLivingBase) t).addPotionEffect(
                        new PotionEffect(Potion.resistance.id, 400, 4));
            }
        }
        w.playSoundEffect(e.posX, e.posY, e.posZ, "random.explode", 3.0F, 1.5F);
    }

    // ---- FLOOD ------------------------------------------------------------

    private static void flood(World w, int cx, int cy, int cz) {
        int r = 8;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= 3; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (!inSphere(dx, dy, dz, r)) continue;
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    if (y > 0 && w.isAirBlock(x, y, z)) {
                        w.setBlock(x, y, z, Blocks.flowing_water, 0, 2);
                    }
                }
            }
        }
        w.playSoundEffect(cx, cy, cz, "liquid.splash", 3.0F, 0.6F);
    }
}
