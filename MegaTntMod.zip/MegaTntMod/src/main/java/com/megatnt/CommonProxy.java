package com.megatnt;

public class CommonProxy {
    public void registerRenderers() {
        // server side: nothing to render
    }
}
