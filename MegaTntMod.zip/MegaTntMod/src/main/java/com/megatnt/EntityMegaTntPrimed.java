package com.megatnt;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;

/**
 * A lit mega TNT. After the fuse runs out it detonates; types with
 * lingerTicks > 0 (nuke fallout, black hole) stay alive, invisible, and
 * keep acting on the world until the linger timer ends.
 */
public class EntityMegaTntPrimed extends Entity {

    private static final int DW_TYPE = 16;
    private static final int DW_EXPLODED = 17;

    public int fuse = 80;
    private int linger = 0;
    private int lingerTotal = 0;
    private EntityLivingBase igniter;

    public EntityMegaTntPrimed(World world) {
        super(world);
        preventEntitySpawning = true;
        setSize(0.98F, 0.98F);
        yOffset = height / 2.0F;
    }

    public EntityMegaTntPrimed(World world, double x, double y, double z,
                               EntityLivingBase igniter, int meta) {
        this(world);
        setPosition(x, y, z);
        float angle = (float) (Math.random() * Math.PI * 2.0);
        motionX = -Math.sin(angle) * 0.02;
        motionY = 0.2;
        motionZ = -Math.cos(angle) * 0.02;
        prevPosX = x;
        prevPosY = y;
        prevPosZ = z;
        this.igniter = igniter;
        dataWatcher.updateObject(DW_TYPE, Integer.valueOf(meta));
        this.fuse = TntType.byMeta(meta).fuse;
    }

    @Override
    protected void entityInit() {
        dataWatcher.addObject(DW_TYPE, Integer.valueOf(0));
        dataWatcher.addObject(DW_EXPLODED, Byte.valueOf((byte) 0));
    }

    public int getTntMeta() {
        return dataWatcher.getWatchableObjectInt(DW_TYPE);
    }

    public TntType getType() {
        return TntType.byMeta(getTntMeta());
    }

    public boolean isExploded() {
        return dataWatcher.getWatchableObjectByte(DW_EXPLODED) != 0;
    }

    private void setExploded(boolean value) {
        dataWatcher.updateObject(DW_EXPLODED, Byte.valueOf((byte) (value ? 1 : 0)));
    }

    @Override
    protected boolean canTriggerWalking() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return !isDead && !isExploded();
    }

    @Override
    public float getShadowSize() {
        return 0.0F;
    }

    @Override
    public void onUpdate() {
        prevPosX = posX;
        prevPosY = posY;
        prevPosZ = posZ;

        if (!isExploded()) {
            motionY -= 0.04;
            moveEntity(motionX, motionY, motionZ);
            motionX *= 0.98;
            motionY *= 0.98;
            motionZ *= 0.98;
            if (onGround) {
                motionX *= 0.7;
                motionZ *= 0.7;
                motionY *= -0.5;
            }
        }

        if (worldObj.isRemote) {
            if (!isExploded()) {
                worldObj.spawnParticle("smoke", posX, posY + 0.7, posZ, 0.0, 0.0, 0.0);
            }
            return;
        }

        if (!isExploded()) {
            if (--fuse <= 0) {
                detonate();
            }
        } else {
            lingerTick();
        }
    }

    private void detonate() {
        TntType type = getType();
        setExploded(true);
        motionX = motionY = motionZ = 0.0;

        TntEffects.detonate(worldObj, this, type, igniter);

        if (type.lingerTicks > 0) {
            linger = type.lingerTicks;
            lingerTotal = type.lingerTicks;
        } else {
            setDead();
        }
    }

    private void lingerTick() {
        TntType type = getType();
        int elapsed = lingerTotal - linger;
        TntEffects.lingerTick(worldObj, this, type, elapsed, lingerTotal);
        if (--linger <= 0) {
            TntEffects.lingerEnd(worldObj, this, type);
            setDead();
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound tag) {
        tag.setByte("Fuse", (byte) Math.min(fuse, 127));
        tag.setInteger("TntMeta", getTntMeta());
        tag.setBoolean("Exploded", isExploded());
        tag.setInteger("Linger", linger);
        tag.setInteger("LingerTotal", lingerTotal);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound tag) {
        fuse = tag.getByte("Fuse");
        dataWatcher.updateObject(DW_TYPE, Integer.valueOf(tag.getInteger("TntMeta")));
        setExploded(tag.getBoolean("Exploded"));
        linger = tag.getInteger("Linger");
        lingerTotal = tag.getInteger("LingerTotal");
    }
}
