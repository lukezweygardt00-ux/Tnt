package com.megatnt;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

/** Same look as vanilla primed TNT (pulse + white flash) but with our per-type texture. */
@SideOnly(Side.CLIENT)
public class RenderMegaTntPrimed extends Render {

    private final RenderBlocks blockRenderer = new RenderBlocks();

    public RenderMegaTntPrimed() {
        this.shadowSize = 0.5F;
    }

    @Override
    public void doRender(Entity entity, double x, double y, double z, float yaw, float partialTicks) {
        EntityMegaTntPrimed tnt = (EntityMegaTntPrimed) entity;
        if (tnt.isExploded()) {
            return; // lingering effect entities are invisible
        }

        int meta = tnt.getTntMeta();

        GL11.glPushMatrix();
        GL11.glTranslatef((float) x, (float) y, (float) z);

        float timeLeft = (float) tnt.fuse - partialTicks + 1.0F;
        if (timeLeft < 10.0F) {
            float pulse = 1.0F - timeLeft / 10.0F;
            if (pulse < 0.0F) pulse = 0.0F;
            if (pulse > 1.0F) pulse = 1.0F;
            pulse = pulse * pulse;
            pulse = pulse * pulse;
            float scale = 1.0F + pulse * 0.3F;
            GL11.glScalef(scale, scale, scale);
        }

        float flashAlpha = (1.0F - timeLeft / 100.0F) * 0.8F;
        this.bindEntityTexture(tnt);
        this.blockRenderer.renderBlockAsItem(MegaTntMod.megaTnt, meta, tnt.getBrightness(partialTicks));

        if (tnt.fuse / 5 % 2 == 0) {
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_LIGHTING);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_DST_ALPHA);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, flashAlpha);
            GL11.glPolygonOffset(-3.0F, -3.0F);
            GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
            this.blockRenderer.renderBlockAsItem(MegaTntMod.megaTnt, meta, 1.0F);
            GL11.glPolygonOffset(0.0F, 0.0F);
            GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glEnable(GL11.GL_LIGHTING);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
        }

        GL11.glPopMatrix();
    }

    @Override
    protected ResourceLocation getEntityTexture(Entity entity) {
        return TextureMap.locationBlocksTexture;
    }
}
