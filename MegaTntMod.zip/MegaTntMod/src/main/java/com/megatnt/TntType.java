package com.megatnt;

/**
 * Every TNT variant. The ordinal is the block metadata, so DO NOT reorder
 * existing entries once worlds exist; append new ones at the end (max 16).
 */
public enum TntType {
    //          id            fuse  lingerTicks
    NUKE(      "nuke",        100,  400),   // lingers as radioactive fallout
    BLACK_HOLE("black_hole",   80,  300),   // lingers as a growing black hole
    VILLAGE(   "village",      60,    0),
    LIGHTNING( "lightning",    60,    0),
    ICE(       "ice",          60,    0),
    LAVA(      "lava",         60,    0),
    FIRE(      "fire",         60,    0),
    FOREST(    "forest",       60,    0),
    ORE(       "ore",          60,    0),
    ZOMBIE(    "zombie",       60,    0),
    PARTY(     "party",        60,    0),
    LAUNCH(    "launch",       60,    0),
    FLOOD(     "flood",        60,    0);

    public final String id;
    public final int fuse;
    public final int lingerTicks;

    TntType(String id, int fuse, int lingerTicks) {
        this.id = id;
        this.fuse = fuse;
        this.lingerTicks = lingerTicks;
    }

    public static TntType byMeta(int meta) {
        TntType[] all = values();
        if (meta < 0 || meta >= all.length) {
            return NUKE;
        }
        return all[meta];
    }
}
