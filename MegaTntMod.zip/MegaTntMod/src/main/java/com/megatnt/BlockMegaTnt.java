package com.megatnt;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IIcon;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

import java.util.List;

/** One block, 13 variants (metadata = TntType ordinal). */
public class BlockMegaTnt extends Block {

    @SideOnly(Side.CLIENT)
    private IIcon[] icons;

    public BlockMegaTnt() {
        super(Material.tnt);
        setHardness(0.0F);
        setStepSound(soundTypeGrass);
        setBlockName("megaTnt");
        setCreativeTab(MegaTntMod.tab);
    }

    @Override
    public int damageDropped(int meta) {
        return meta;
    }

    @Override
    @SideOnly(Side.CLIENT)
    public IIcon getIcon(int side, int meta) {
        if (meta < 0 || meta >= icons.length) {
            meta = 0;
        }
        return icons[meta];
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister reg) {
        TntType[] types = TntType.values();
        icons = new IIcon[types.length];
        for (int i = 0; i < types.length; i++) {
            icons[i] = reg.registerIcon(MegaTntMod.MODID + ":tnt_" + types[i].id);
        }
    }

    @Override
    @SideOnly(Side.CLIENT)
    @SuppressWarnings({"unchecked", "rawtypes"})
    public void getSubBlocks(Item item, CreativeTabs tab, List list) {
        for (int i = 0; i < TntType.values().length; i++) {
            list.add(new ItemStack(item, 1, i));
        }
    }

    // ---- ignition ---------------------------------------------------------

    @Override
    public void onBlockAdded(World world, int x, int y, int z) {
        super.onBlockAdded(world, x, y, z);
        if (world.isBlockIndirectlyGettingPowered(x, y, z)) {
            ignite(world, x, y, z, null);
        }
    }

    @Override
    public void onNeighborBlockChange(World world, int x, int y, int z, Block neighbor) {
        if (world.isBlockIndirectlyGettingPowered(x, y, z)) {
            ignite(world, x, y, z, null);
        }
    }

    @Override
    public void onBlockDestroyedByExplosion(World world, int x, int y, int z, Explosion explosion) {
        if (!world.isRemote) {
            int meta = world.getBlockMetadata(x, y, z);
            EntityMegaTntPrimed tnt = new EntityMegaTntPrimed(
                    world, x + 0.5, y + 0.5, z + 0.5, explosion.getExplosivePlacedBy(), meta);
            // chain reactions go off quickly
            tnt.fuse = world.rand.nextInt(Math.max(1, tnt.fuse / 4)) + tnt.fuse / 8;
            world.spawnEntityInWorld(tnt);
        }
    }

    @Override
    public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player,
                                    int side, float hitX, float hitY, float hitZ) {
        ItemStack held = player.getCurrentEquippedItem();
        if (held != null) {
            Item item = held.getItem();
            if (item == Items.flint_and_steel || item == Items.fire_charge) {
                ignite(world, x, y, z, player);
                if (item == Items.flint_and_steel) {
                    held.damageItem(1, player);
                } else if (!player.capabilities.isCreativeMode) {
                    held.stackSize--;
                }
                return true;
            }
        }
        return super.onBlockActivated(world, x, y, z, player, side, hitX, hitY, hitZ);
    }

    @Override
    public boolean canDropFromExplosion(Explosion explosion) {
        return false;
    }

    /** Replace the block with a primed entity of the same type. */
    public void ignite(World world, int x, int y, int z, EntityLivingBase igniter) {
        if (world.isRemote) {
            return;
        }
        int meta = world.getBlockMetadata(x, y, z);
        world.setBlockToAir(x, y, z);
        EntityMegaTntPrimed tnt = new EntityMegaTntPrimed(
                world, x + 0.5, y + 0.5, z + 0.5, igniter, meta);
        world.spawnEntityInWorld(tnt);
        world.playSoundAtEntity(tnt, "game.tnt.primed", 1.0F, 1.0F);
    }
}
