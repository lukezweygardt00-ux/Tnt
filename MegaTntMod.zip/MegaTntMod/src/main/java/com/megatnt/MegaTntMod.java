package com.megatnt;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = MegaTntMod.MODID, name = "Mega TNT Pack", version = MegaTntMod.VERSION)
public class MegaTntMod {
    public static final String MODID = "megatnt";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static MegaTntMod instance;

    @SidedProxy(clientSide = "com.megatnt.ClientProxy", serverSide = "com.megatnt.CommonProxy")
    public static CommonProxy proxy;

    public static Block megaTnt;

    public static final CreativeTabs tab = new CreativeTabs("megatnt") {
        @Override
        @SideOnly(Side.CLIENT)
        public Item getTabIconItem() {
            return Item.getItemFromBlock(Blocks.tnt);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        megaTnt = new BlockMegaTnt();
        GameRegistry.registerBlock(megaTnt, ItemBlockMegaTnt.class, "megaTnt");

        EntityRegistry.registerModEntity(
                EntityMegaTntPrimed.class, "MegaTntPrimed", 0, this, 160, 10, true);

        proxy.registerRenderers();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Recipes.register();

        RadiationHandler radiation = new RadiationHandler();
        FMLCommonHandler.instance().bus().register(radiation); // player ticks
        MinecraftForge.EVENT_BUS.register(radiation);          // milk cure
    }
}
