package com.megatnt;

import net.minecraft.block.Block;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class ItemBlockMegaTnt extends ItemBlock {

    public ItemBlockMegaTnt(Block block) {
        super(block);
        setHasSubtypes(true);
        setMaxDamage(0);
    }

    @Override
    public int getMetadata(int damage) {
        return damage;
    }

    @Override
    public String getUnlocalizedName(ItemStack stack) {
        return "tile." + MegaTntMod.MODID + "." + TntType.byMeta(stack.getItemDamage()).id;
    }
}
